import{_ as e,o as i,c as n,d as a}from"./app.e2427bec.js";const t={},d=a(`<h1 id="tee" tabindex="-1"><a class="header-anchor" href="#tee" aria-hidden="true">#</a> tee</h1><div class="custom-container tip"><p class="custom-container-title">TIP</p><p>Similar to the traditional <code>tee</code> command, it is used to read standard input data and output its contents into a file.</p><p><code>tee</code> will read data from standard input device, output its content to standard output device, and save it as a file.</p></div><h2 id="usage" tabindex="-1"><a class="header-anchor" href="#usage" aria-hidden="true">#</a> Usage</h2><div class="language-text ext-text line-numbers-mode"><pre class="language-text"><code> USAGE:
   tee [-a] [-h] [file]

 SUMMARY:
   tee command for pipes.

 EXAMPLES:
  sysprop | tee /path/to/logfile | grep java
  sysprop | tee -a /path/to/logfile | grep java

 WIKI:
   https://arthas.aliyun.com/doc/tee

 OPTIONS:
 -a, --append                              Append to file
 -h, --help                                this help
 &lt;file&gt;                                    File path
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div>`,4),s=[d];function l(c,r){return i(),n("div",null,s)}const v=e(t,[["render",l],["__file","tee.html.vue"]]);export{v as default};
